# Aymr

A Fabric mod for Minecraft **26.2 "Chaos Cubed"**, adding Aymr — Edelgard's Crest-forged relic axe
from Fire Emblem: Three Houses.

## What it does

- **Crest Stone** — crafted from a Nether Star (center), 4 Netherite Ingots (corners), and
  4 Blocks of Iron (cardinal directions).
- **Aymr** — crafted from 1 Netherite Axe + 1 Crest Stone + 2 Bone Blocks (shapeless).
  - Hits far harder than a netherite axe (custom `ToolMaterial`, higher durability, mining speed,
    and enchantability).
  - Every hit: sets the target on fire, inflicts Wither II ("withering fire"), and applies heavy
    bonus knockback.
  - **Left click ability — Blink Strike:** teleports you to the nearest other living entity within
    12 blocks and deals a large bonus blow, on top of your normal swing. 3-second cooldown per hit,
    but if the blink-strike kills its target in one shot, the cooldown is skipped entirely — chain
    through a whole pack as long as you keep one-shotting them.
  - **Live texture swap:** Aymr glows (active texture) whenever Blink Strike is ready, and turns
    dull/grey (dormant texture) while it's on cooldown, so you can tell the ability's state at a
    glance without checking a HUD. This uses the item's own weapon art (split into two variants)
    and the 1.21.4+ conditional item-model system (`minecraft:condition` keyed off a boolean flag
    in the item's `minecraft:custom_model_data` component), toggled server-side each tick in
    `AymrAxeItem#inventoryTick`.

## Why this looks different from a "normal" Fabric mod

Minecraft 26.1/26.2 dropped Yarn mappings entirely — mods now compile directly against Mojang's
official (deobfuscated) names, and Fabric Loom no longer remaps anything. Class/method names you
may remember from older tutorials (`StatusEffects`, `PlayerEntity`, `postHit`, `ToolMaterials`,
`getItemCooldownManager()`...) don't exist anymore; this project uses the current names
(`MobEffects`, `Player`/`ServerPlayer`, `hurtEnemy`, `ToolMaterial`, a custom data component for
the ability cooldown instead of the old cooldown manager, etc.), pulled from Fabric's own
just-published 26.2 documentation.

Because 26.2 is only a couple of months old, a small number of very specific method names in here
(`Entity#teleportTo`, `Entity#setRemainingFireTicks`, `ServerPlayNetworking.Context#server()`)
were written from the most stable long-standing Mojang names rather than a directly-confirmed
26.2 source snippet. If Gradle reports an unresolved-symbol error on one of those lines, it's
almost certainly just a rename — right-click → "fix imports"/quick-fix in your IDE will usually
find the new name immediately.

## Building

1. Install JDK 25 and open the project folder in IntelliJ IDEA (recommended) or run:
   ```
   ./gradlew build
   ```
   (On first run this downloads Minecraft 26.2 + Fabric Loader 0.19.3 + Fabric API — this can take
   a while and needs an internet connection.)
2. The built mod jar will be in `build/libs/`.
3. Drop it into a Fabric 26.2 instance's `mods` folder, alongside Fabric API 0.156.0+26.2 or newer.

## Customizing

- All the numeric tuning (damage, knockback, fire/Wither duration, blink radius/cooldown) lives at
  the top of `AymrMod.java`.
- The crafting recipes are plain JSON in `src/main/resources/data/aymr/recipe/` — edit freely.
- `aymr_active.png` / `aymr_dormant.png` (128x128) are cropped from the artwork you provided;
  `crest_stone.png` is still simple placeholder art — swap it for real art whenever you like (or
  make a proper hand-held 3D model instead of the flat `item/handheld` parent for either item).
- If you'd rather the texture always show one state (e.g. always "active"), delete the
  `minecraft:condition` block in `assets/aymr/items/aymr.json` and point `model` straight at
  `aymr:item/aymr_active`.
