package com.aymrmod.client;

import com.aymrmod.AymrMod;
import com.aymrmod.network.BlinkStrikePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;

public class AymrModClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		// Fires every time the attack key (left click) is pressed while holding Aymr.
		// Returning false leaves the normal vanilla attack (swing + front-facing hit) intact,
		// so the blink strike is an *extra* effect layered on top of the regular swing.
		ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> {
			if (clickCount != 0 && player.getMainHandItem().is(AymrMod.AYMR)) {
				ClientPlayNetworking.send(new BlinkStrikePayload());
			}
			return false;
		});
	}
}
