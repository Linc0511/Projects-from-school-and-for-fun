package com.aymrmod.network;

import com.aymrmod.AymrMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Sent client -> server whenever the player presses attack while holding Aymr.
 * Carries no data; the server looks up the player's held item and nearby entities itself.
 */
public record BlinkStrikePayload() implements CustomPacketPayload {

	public static final Identifier PAYLOAD_ID = AymrMod.id("blink_strike");

	public static final CustomPacketPayload.Type<BlinkStrikePayload> TYPE =
			new CustomPacketPayload.Type<>(PAYLOAD_ID);

	public static final StreamCodec<RegistryFriendlyByteBuf, BlinkStrikePayload> CODEC =
			StreamCodec.unit(new BlinkStrikePayload());

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
