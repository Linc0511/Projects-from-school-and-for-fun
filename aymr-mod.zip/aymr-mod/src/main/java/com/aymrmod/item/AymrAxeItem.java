package com.aymrmod.item;

import com.aymrmod.AymrMod;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.CustomModelData;

import java.util.List;

/**
 * Aymr - a relic axe forged from a Crest Stone.
 * <p>
 * Every hit sets the target on fire, inflicts Wither ("withering fire"), and applies heavy
 * bonus knockback. The teleport "blink strike" ability lives in {@link AymrMod}, since it is
 * triggered by the attack key itself (via a network payload) rather than only on a landed hit -
 * see {@code AymrModClient} for the trigger and {@code AymrMod#handleBlinkStrike} for the logic.
 * <p>
 * The item also swaps between a "dormant" (grey) and "active" (glowing) texture depending on
 * whether the blink strike is off cooldown - see the {@code minecraft:condition} client item at
 * {@code assets/aymr/items/aymr.json}, driven by the boolean flag written in
 * {@link #inventoryTick}.
 */
public class AymrAxeItem extends AxeItem {

	public AymrAxeItem(ToolMaterial material, float attackDamage, float attackSpeed, Properties properties) {
		super(material, attackDamage, attackSpeed, properties);
	}

	@Override
	public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		boolean result = super.hurtEnemy(stack, target, attacker);

		if (!attacker.level().isClientSide()) {
			applyOnHitEffects(target, attacker);
		}

		return result;
	}

	@Override
	public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);

		boolean ready = level.getGameTime() >= stack.getOrDefault(AymrMod.BLINK_READY_AT, 0L);

		CustomModelData current = stack.get(DataComponents.CUSTOM_MODEL_DATA);
		boolean currentlyActive = current != null && !current.flags().isEmpty() && current.flags().get(0);

		if (ready != currentlyActive) {
			stack.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(List.of(), List.of(ready), List.of(), List.of()));
		}
	}

	/**
	 * Shared "on hit" flavor effects, used both by normal melee hits (hurtEnemy above) and by
	 * the teleport blink-strike bonus hit in {@link AymrMod#handleBlinkStrike}.
	 */
	public static void applyOnHitEffects(LivingEntity target, LivingEntity attacker) {
		target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), AymrMod.ON_HIT_FIRE_TICKS));
		target.addEffect(new MobEffectInstance(MobEffects.WITHER, AymrMod.ON_HIT_WITHER_TICKS, AymrMod.ON_HIT_WITHER_AMPLIFIER));

		double dx = target.getX() - attacker.getX();
		double dz = target.getZ() - attacker.getZ();
		target.knockback(AymrMod.ON_HIT_KNOCKBACK, -dx, -dz);
	}
}
