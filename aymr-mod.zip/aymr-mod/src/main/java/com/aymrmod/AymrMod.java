package com.aymrmod;

import com.aymrmod.item.AymrAxeItem;
import com.aymrmod.network.BlinkStrikePayload;
import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.function.Function;

public class AymrMod implements ModInitializer {

	public static final String MOD_ID = "aymr";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	// ---- Tunables -------------------------------------------------------
	public static final float BLINK_BONUS_DAMAGE = 22.0F;      // extra "large blow" dealt to the blink target
	public static final float ON_HIT_KNOCKBACK = 2.2F;         // extra knockback strength applied on every hit
	public static final int ON_HIT_FIRE_TICKS = 100;           // 5 seconds of fire on every hit
	public static final int ON_HIT_WITHER_TICKS = 140;         // ~7 seconds of Wither ("withering fire") on every hit
	public static final int ON_HIT_WITHER_AMPLIFIER = 1;       // Wither II
	public static final double BLINK_SEARCH_RADIUS = 12.0D;    // how far the blink strike can reach
	public static final int BLINK_COOLDOWN_TICKS = 60;         // 3 second cooldown, waived on a one-shot kill

	// ---- Identifiers ------------------------------------------------------
	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	// ---- Item resource keys ------------------------------------------------
	public static final ResourceKey<Item> CREST_STONE_KEY = ResourceKey.create(Registries.ITEM, id("crest_stone"));
	public static final ResourceKey<Item> AYMR_KEY = ResourceKey.create(Registries.ITEM, id("aymr"));

	// ---- Tags used by the custom tool material -----------------------------
	// Reuses vanilla's "incorrect blocks for netherite tool" tag so Aymr mines exactly what a netherite axe can.
	public static final TagKey<Block> INCORRECT_FOR_AYMR =
			TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("minecraft", "incorrect_for_netherite_tool"));
	// Custom repair tag - add netherite_ingot (and anything else you like) via a tags datapack entry.
	public static final TagKey<Item> REPAIRS_AYMR = TagKey.create(Registries.ITEM, id("repairs_aymr"));

	// ---- Custom tool material: stronger than netherite across the board ----
	public static final ToolMaterial AYMR_MATERIAL = new ToolMaterial(
			INCORRECT_FOR_AYMR,
			2600,   // durability (netherite axe is 2031)
			11.0F,  // mining speed
			9.0F,   // attack damage bonus
			28,     // enchantment value
			REPAIRS_AYMR
	);

	// ---- Custom data component: server game-time the blink-strike is next usable ----
	public static final DataComponentType<Long> BLINK_READY_AT = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			id("blink_ready_at"),
			DataComponentType.<Long>builder().persistent(Codec.LONG).build()
	);

	// ---- Item registration helper (mirrors Mojang's own Items class pattern) ----
	public static Item register(ResourceKey<Item> itemKey, Function<Item.Properties, Item> itemFactory, Item.Properties settings) {
		Item item = itemFactory.apply(settings.setId(itemKey));
		Registry.register(BuiltInRegistries.ITEM, itemKey, item);
		return item;
	}

	public static final Item CREST_STONE = register(
			CREST_STONE_KEY,
			Item::new,
			new Item.Properties()
	);

	public static final Item AYMR = register(
			AYMR_KEY,
			settings -> new AymrAxeItem(AYMR_MATERIAL, 8.0F, -3.0F, settings),
			new Item.Properties()
					.fireResistant()
					.component(BLINK_READY_AT, 0L)
					// Starts "active" (glowing) - see AymrAxeItem#inventoryTick, which keeps this
					// flag in sync with whether the blink strike is off cooldown.
					.component(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(List.of(), List.of(true), List.of(), List.of()))
	);

	@Override
	public void onInitialize() {
		LOGGER.info("Forging Aymr...");

		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT)
				.register(creativeTab -> {
					creativeTab.accept(CREST_STONE);
					creativeTab.accept(AYMR);
				});

		PayloadTypeRegistry.serverboundPlay().register(BlinkStrikePayload.TYPE, BlinkStrikePayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(BlinkStrikePayload.TYPE, (payload, context) ->
				context.server().execute(() -> handleBlinkStrike(context.player())));
	}

	/**
	 * The active "blink strike" ability. Fired every time the player presses attack while
	 * holding Aymr. Teleports the player to the nearest other living entity within range and
	 * deals a big bonus hit. Goes on cooldown unless that blow is a one-shot kill, letting you
	 * chain through a pack of enemies as long as you keep one-shotting them.
	 */
	private static void handleBlinkStrike(ServerPlayer player) {
		ItemStack mainHand = player.getMainHandItem();
		if (!mainHand.is(AYMR)) {
			return;
		}

		ServerLevel level = player.serverLevel();
		long readyAt = mainHand.getOrDefault(BLINK_READY_AT, 0L);
		if (level.getGameTime() < readyAt) {
			return; // still on cooldown
		}

		AABB searchBox = player.getBoundingBox().inflate(BLINK_SEARCH_RADIUS);
		List<LivingEntity> nearby = level.getEntitiesOfClass(
				LivingEntity.class,
				searchBox,
				entity -> entity != player && entity.isAlive() && entity.distanceTo(player) <= BLINK_SEARCH_RADIUS
		);

		LivingEntity target = null;
		double closest = Double.MAX_VALUE;
		for (LivingEntity candidate : nearby) {
			double distanceSq = candidate.distanceToSqr(player);
			if (distanceSq < closest) {
				closest = distanceSq;
				target = candidate;
			}
		}

		if (target == null) {
			return; // nothing to blink to - ability stays ready, no cooldown wasted
		}

		teleportNextTo(player, target);

		var damageSource = level.damageSources().playerAttack(player);
		target.hurtServer(level, damageSource, BLINK_BONUS_DAMAGE);
		AymrAxeItem.applyOnHitEffects(target, player);

		if (target.isDeadOrDying()) {
			// One-shot kill: keep the ability fully ready so the player can chain into the next enemy.
			mainHand.set(BLINK_READY_AT, level.getGameTime());
		} else {
			mainHand.set(BLINK_READY_AT, level.getGameTime() + BLINK_COOLDOWN_TICKS);
		}
	}

	private static void teleportNextTo(ServerPlayer player, LivingEntity target) {
		Vec3 fromTargetToPlayer = player.position().subtract(target.position());
		double horizontalLength = Math.sqrt(fromTargetToPlayer.x * fromTargetToPlayer.x + fromTargetToPlayer.z * fromTargetToPlayer.z);

		double nx = 1.0D;
		double nz = 0.0D;
		if (horizontalLength > 0.001D) {
			nx = fromTargetToPlayer.x / horizontalLength;
			nz = fromTargetToPlayer.z / horizontalLength;
		}

		double destX = target.getX() + nx * 1.5D;
		double destY = target.getY();
		double destZ = target.getZ() + nz * 1.5D;

		player.teleportTo(destX, destY, destZ);
	}
}
