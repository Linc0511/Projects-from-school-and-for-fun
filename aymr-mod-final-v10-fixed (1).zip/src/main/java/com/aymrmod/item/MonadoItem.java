package com.aymrmod.item;

import com.aymrmod.AymrMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * The Monado - shift-right-click cycles through its seven modes (see AymrMod.MONADO_MODES).
 * Each mode's passive buffs are applied server-side every tick from a global player-tick loop
 * in AymrMod (see tickMonadoEffects), not from here, since that approach self-corrects cleanly
 * if the item is swapped out of hand rather than needing explicit cleanup on unequip. Purge
 * (and God, which includes everything) strip the target's positive effects on a landed hit,
 * which *is* handled here via hurtEnemy - a real per-hit hook, unlike the passive buffs.
 */
public class MonadoItem extends Item {

	public MonadoItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (!player.isShiftKeyDown()) {
			return InteractionResult.PASS;
		}
		if (level.isClientSide() || !(player instanceof ServerPlayer serverPlayer)) {
			return InteractionResult.SUCCESS_SERVER;
		}
		AymrMod.cycleMonadoMode(serverPlayer, player.getItemInHand(hand), (ServerLevel) level);
		return InteractionResult.SUCCESS_SERVER;
	}

	@Override
	public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		super.hurtEnemy(stack, target, attacker);
		if (attacker.level().isClientSide()) {
			return;
		}
		String mode = AymrMod.getMonadoMode(stack);
		if (mode.equals(AymrMod.MONADO_MODE_PURGE) || mode.equals(AymrMod.MONADO_MODE_GOD)) {
			AymrMod.stripPositiveEffects(target);
		}
	}
}
