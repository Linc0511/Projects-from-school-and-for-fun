package com.aymrmod.item;

import com.aymrmod.AymrMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.level.Level;

/**
 * Sword of the Creator - a relic sword with two active abilities:
 * <ul>
 *   <li>Sublime Heaven (see {@code AymrMod.handleSublimeHeaven}) - an extended sweeping-edge
 *   burst hitting every living entity in a radius, triggered by the attack key via
 *   {@code ActivateRelicPayload}, same as Aymr's blink strike.</li>
 *   <li>Time Stop (see {@code AymrMod.handleTimeStop}) - freezes every mob in a wide radius for
 *   a full minute, triggered by shift-right-click here directly (its own separate, much longer
 *   cooldown from Sublime Heaven's).</li>
 * </ul>
 * <p>
 * As of 26.2, {@code SwordItem} no longer exists - sword behavior lives in the vanilla
 * {@code minecraft:weapon} data component instead, attached via {@link Properties#sword}. This
 * now extends plain {@link Item}, same as any other tiered weapon.
 */
public class SwordOfTheCreatorItem extends Item {

	public SwordOfTheCreatorItem(ToolMaterial material, float attackDamage, float attackSpeed, Properties properties) {
		super(properties.sword(material, attackDamage, attackSpeed));
	}

	@Override
	public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		AymrMod.tickActiveTexture(stack, level, entity, slot);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (!player.isShiftKeyDown()) {
			return InteractionResult.PASS;
		}
		if (level.isClientSide() || !(player instanceof ServerPlayer serverPlayer)) {
			return InteractionResult.SUCCESS_SERVER;
		}
		AymrMod.handleTimeStop(serverPlayer, player.getItemInHand(hand));
		return InteractionResult.SUCCESS_SERVER;
	}
}

