package com.aymrmod;

import com.aymrmod.item.AreadbharSpearItem;
import com.aymrmod.item.AymrAxeItem;
import com.aymrmod.item.FailnaughtBowItem;
import com.aymrmod.item.MonadoItem;
import com.aymrmod.item.SwordOfTheCreatorItem;
import com.aymrmod.network.ActivateRelicPayload;
import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;

public class AymrMod implements ModInitializer {

	public static final String MOD_ID = "aymr";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	// ---- Tunables ---------------------------------------------------------

	// Aymr - Blink Strike
	public static final float BLINK_BONUS_DAMAGE = 100.0F;
	public static final double BLINK_SEARCH_RADIUS = 12.0D;
	public static final int BLINK_COOLDOWN_TICKS = 25; // 3s

	// Aymr - on-hit flavor (fire / withering fire / knockback)
	public static final float ON_HIT_KNOCKBACK = 2.2F;
	public static final int ON_HIT_FIRE_TICKS = 250;
	public static final int ON_HIT_WITHER_TICKS = 250;
	public static final int ON_HIT_WITHER_AMPLIFIER = 10;

	// Sword of the Creator - Sublime Heaven (AoE sweep)
	public static final float SUBLIME_HEAVEN_DAMAGE = 25.0F;
	public static final double SUBLIME_HEAVEN_RADIUS = 9.0D;
	public static final int SUBLIME_HEAVEN_COOLDOWN_TICKS = 20; // 3s

	// Sword of the Creator - Time Stop (shift-right-click). A full block-and-entity rewind isn't
	// practical to implement reliably (there's no safe, general way to "undo" arbitrary world
	// edits or resurrect specific dead entities in vanilla), so this is the time-freeze
	// alternative instead: every non-player mob in range is genuinely frozen in place (AI off,
	// velocity zeroed) rather than merely slowed, for a full minute, on a much longer cooldown
	// than the sword's other ability.
	public static final double TIME_STOP_RADIUS = 20.0D;
	public static final int TIME_STOP_DURATION_TICKS = 1200; // 60s
	public static final int TIME_STOP_COOLDOWN_TICKS = 2400; // 120s
	private static final Map<Mob, Long> FROZEN_MOBS = new HashMap<>();

	// Areadbhar - Crest Surge (self buff)
	public static final int CREST_SURGE_DURATION_TICKS = 600; // 10s
	public static final int CREST_SURGE_AMPLIFIER = 5; // Strength III
	public static final int CREST_SURGE_COOLDOWN_TICKS = 20; // 15s
	public static final double CREST_SURGE_LIGHTNING_RADIUS = 12.0D;

	// Failnaught - Fallen Star (self buff on firing an arrow)
	public static final int FALLEN_STAR_DURATION_TICKS = 200; // 10s
	public static final int FALLEN_STAR_RESISTANCE_AMPLIFIER = 10; // Resistance II
	public static final int FALLEN_STAR_STRENGTH_AMPLIFIER = 6; // Strength II
	public static final int FALLEN_STAR_COOLDOWN_TICKS = 20; // 15s

	// Failnaught - Golden Beam (fully-charged shot instead of a normal arrow)
	public static final double BEAM_RANGE = 40.0D;
	public static final float BEAM_DAMAGE = 45.0F;
	public static final int BEAM_FULL_CHARGE_TICKS = 20; // ~1s hold - matches vanilla's own "fully drawn" threshold
	public static final int BEAM_LINGER_TICKS = 12; // ~0.6s of trailing particles after the hit
	public static final int BEAM_FIRE_TICKS = 60;
	public static final int BEAM_ARROW_COUNT = 3;
	public static final float BEAM_ARROW_SPREAD_DEGREES = 8.0F; // fan angle between each bonus arrow
	public static final float BEAM_ARROW_VELOCITY = 3.0F;
	public static final float BEAM_ARROW_INACCURACY = 0.0F; // dead straight, matches the beam

	// Sword of the Creator - Sublime Heaven range ring (visual only, shows the AoE radius)
	public static final int SUBLIME_HEAVEN_RING_POINTS = 72;
	public static final double[] SUBLIME_HEAVEN_RING_HEIGHTS = {0.1D, 0.5D, 0.9D};
	public static final int SUBLIME_HEAVEN_RING_PARTICLES_PER_POINT = 3;

	// Held-relic glow: keeps a relic's active/dormant texture in sync with its cooldown (see
	// tickActiveTexture)

	// ---- Monado: seven modes cycled via shift-right-click, applied passively every tick while
	// held (see tickMonadoEffects) plus Purge/God's on-hit effect-strip (see MonadoItem) ----
	public static final String MONADO_MODE_OFF = "off";
	public static final String MONADO_MODE_SPEED = "speed";
	public static final String MONADO_MODE_JUMP = "jump";
	public static final String MONADO_MODE_BUSTER = "buster";
	public static final String MONADO_MODE_SHIELD = "shield";
	public static final String MONADO_MODE_SMASH = "smash";
	public static final String MONADO_MODE_PURGE = "purge";
	public static final String MONADO_MODE_GOD = "god";
	public static final List<String> MONADO_MODES = List.of(
			MONADO_MODE_OFF, MONADO_MODE_SPEED, MONADO_MODE_JUMP, MONADO_MODE_BUSTER,
			MONADO_MODE_SHIELD, MONADO_MODE_SMASH, MONADO_MODE_PURGE, MONADO_MODE_GOD
	);

	public static final int MONADO_EFFECT_DURATION_TICKS = 60; // refreshed every tick while held, so this is just a safety buffer
	public static final int MONADO_SPEED_AMPLIFIER = 3; // Speed IV
	public static final int MONADO_JUMP_AMPLIFIER = 4; // Jump Boost V
	public static final int MONADO_BUSTER_STRENGTH_AMPLIFIER = 3; // Strength IV
	public static final double MONADO_BUSTER_DAMAGE_BONUS = 12.0D; // flat bonus attack damage, the "massive" part
	public static final int MONADO_SHIELD_RESISTANCE_AMPLIFIER = 9; // Resistance X
	public static final int MONADO_SHIELD_ABSORPTION_AMPLIFIER = 3; // Absorption IV
	public static final int MONADO_SMASH_STRENGTH_AMPLIFIER = 3; // Strength IV
	public static final double MONADO_SMASH_KNOCKBACK_BONUS = 3.0D; // bonus attack-knockback attribute

	// ---- Identifiers --------------------------------------------------------
	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	// ---- Item resource keys --------------------------------------------------
	public static final ResourceKey<Item> CREST_STONE_KEY = ResourceKey.create(Registries.ITEM, id("crest_stone"));
	public static final ResourceKey<Item> AYMR_KEY = ResourceKey.create(Registries.ITEM, id("aymr"));
	public static final ResourceKey<Item> SWORD_OF_THE_CREATOR_KEY = ResourceKey.create(Registries.ITEM, id("sword_of_the_creator"));
	public static final ResourceKey<Item> AREADBHAR_KEY = ResourceKey.create(Registries.ITEM, id("areadbhar"));
	public static final ResourceKey<Item> FAILNAUGHT_KEY = ResourceKey.create(Registries.ITEM, id("failnaught"));
	public static final ResourceKey<Item> MONADO_KEY = ResourceKey.create(Registries.ITEM, id("monado"));

	// ---- Tags used by the custom tool material -------------------------------
	public static final TagKey<Block> INCORRECT_FOR_RELIC_TOOL =
			TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("minecraft", "incorrect_for_netherite_tool"));
	public static final TagKey<Item> REPAIRS_RELICS = TagKey.create(Registries.ITEM, id("repairs_relics"));

	// Shared material for the edged relics (Aymr, Sword of the Creator).
	public static final ToolMaterial RELIC_MATERIAL = new ToolMaterial(
			INCORRECT_FOR_RELIC_TOOL,
			30000,   // durability (netherite is 2031)
			11.0F,  // mining speed
			15.0F,   // attack damage bonus
			28,     // enchantment value
			REPAIRS_RELICS
	);

	// ---- Custom data component: server game-time an ability is next usable ----
	// Shared by every relic weapon's active ability.
	public static final DataComponentType<Long> ABILITY_READY_AT = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			id("ability_ready_at"),
			DataComponentType.<Long>builder().persistent(Codec.LONG).build()
	);

	// Separate cooldown just for Sword of the Creator's Time Stop (shift-right-click), tracked
	// independently from Sublime Heaven's attack-key cooldown above since they're triggered
	// differently and Time Stop's cooldown is much longer.
	public static final DataComponentType<Long> TIME_STOP_READY_AT = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			id("time_stop_ready_at"),
			DataComponentType.<Long>builder().persistent(Codec.LONG).build()
	);

	private static final CustomModelData ACTIVE_MODEL_DATA = new CustomModelData(List.of(), List.of(true), List.of(), List.of());
	private static final CustomModelData DORMANT_MODEL_DATA = new CustomModelData(List.of(), List.of(false), List.of(), List.of());

	// ---- Golden Beam: short-lived trailing particle effect, ticked server-side ----
	private static final DustParticleOptions GOLD_BEAM_DUST = new DustParticleOptions(0xFFD126, 1.6F);
	private static final List<BeamEffect> ACTIVE_BEAMS = new ArrayList<>();

	private static final class BeamEffect {
		final ServerLevel level;
		final Vec3 start;
		final Vec3 end;
		int ticksRemaining;

		BeamEffect(ServerLevel level, Vec3 start, Vec3 end, int ticksRemaining) {
			this.level = level;
			this.start = start;
			this.end = end;
			this.ticksRemaining = ticksRemaining;
		}
	}

	// ---- Time Stop: players frozen in place, tracked separately from mobs since Player isn't a
	// Mob and has no AI to switch off - see handleTimeStop and the freeze-tick loop below.
	private static final Map<ServerPlayer, FrozenPlayer> FROZEN_PLAYERS = new HashMap<>();

	private static final class FrozenPlayer {
		final Vec3 lockedPosition;
		final long unfreezeAt;

		FrozenPlayer(Vec3 lockedPosition, long unfreezeAt) {
			this.lockedPosition = lockedPosition;
			this.unfreezeAt = unfreezeAt;
		}
	}

	// ---- Item registration helper (mirrors Mojang's own Items class pattern) ----
	public static Item register(ResourceKey<Item> itemKey, Function<Item.Properties, Item> itemFactory, Item.Properties settings) {
		Item item = itemFactory.apply(settings.setId(itemKey));
		Registry.register(BuiltInRegistries.ITEM, itemKey, item);
		return item;
	}

	private static Item.Properties relicProperties() {
		return new Item.Properties()
				.fireResistant()
				.component(ABILITY_READY_AT, 0L)
				.component(DataComponents.CUSTOM_MODEL_DATA, ACTIVE_MODEL_DATA);
	}

	public static final Item CREST_STONE = register(CREST_STONE_KEY, Item::new, new Item.Properties());

	public static final Item AYMR = register(
			AYMR_KEY,
			settings -> new AymrAxeItem(RELIC_MATERIAL, 16.0F, -3.0F, settings),
			relicProperties()
				.enchantable(25)
	);

	public static final Item SWORD_OF_THE_CREATOR = register(
			SWORD_OF_THE_CREATOR_KEY,
			settings -> new SwordOfTheCreatorItem(RELIC_MATERIAL, 12.0F, -2.4F, settings),
			relicProperties()
				.enchantable(25)
	);

	public static final Item AREADBHAR = register(
		AREADBHAR_KEY,
		settings -> new AreadbharSpearItem(
				settings.spear(RELIC_MATERIAL, 1.15F, 1.2F, 0.4F, 2.5F, 12.0F, 5.5F, 5.1F, 8.75F, 4.6F)
		),
		relicProperties().enchantable(25)
	);

	public static final Item FAILNAUGHT = register(
			FAILNAUGHT_KEY,
			FailnaughtBowItem::new,
			relicProperties().enchantable(25)
	);

	// Monado doesn't use the shared active/dormant relicProperties() - its glow is a constant
	// part of the model (the blue trim), not a cooldown-driven toggle, and its "model state" is
	// which of the seven modes is selected rather than a ready/dormant flag.
	public static final Item MONADO = register(
			MONADO_KEY,
			MonadoItem::new,
			new Item.Properties()
					.fireResistant()
					.durability(4000)
					.enchantable(25)
					.component(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(List.of(), List.of(), List.of(MONADO_MODE_OFF), List.of()))
	);

	private static final Identifier MONADO_BUSTER_DAMAGE_ID = id("monado_buster_damage");
	private static final Identifier MONADO_SMASH_KNOCKBACK_ID = id("monado_smash_knockback");

	@Override
	public void onInitialize() {
		LOGGER.info("Forging the Hero's Relics...");

		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT)
				.register(creativeTab -> {
					creativeTab.accept(CREST_STONE);
					creativeTab.accept(AYMR);
					creativeTab.accept(SWORD_OF_THE_CREATOR);
					creativeTab.accept(AREADBHAR);
					creativeTab.accept(FAILNAUGHT);
					creativeTab.accept(MONADO);
				});

		PayloadTypeRegistry.serverboundPlay().register(ActivateRelicPayload.TYPE, ActivateRelicPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ActivateRelicPayload.TYPE, (payload, context) ->
				context.server().execute(() -> dispatchMeleeAbility(context.player())));

		// Ticks the Golden Beam's short trailing particle effect - see fireGoldenBeam below.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (ACTIVE_BEAMS.isEmpty()) {
				return;
			}
			ACTIVE_BEAMS.removeIf(beam -> {
				spawnBeamParticles(beam.level, beam.start, beam.end);
				beam.ticksRemaining--;
				return beam.ticksRemaining <= 0;
			});
		});

		// Applies (or cleans up) Monado's passive per-mode buffs every tick for every player.
		// Driven top-down from "is Monado currently in a hand right now" rather than from the
		// item's own inventoryTick, so switching away from Monado cleanly clears its attribute
		// bonuses on the very next tick with no separate on-unequip hook needed.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				tickMonadoEffects(player);
			}
		});

		// Unfreezes any mob whose Time Stop duration has expired, and cleans up entries for mobs
		// that died or unloaded while frozen so this map can't leak. Also re-zeros velocity every
		// tick for anything still frozen, since a few things (explosions, other knockback) can
		// otherwise nudge a no-AI mob even though it can't act on its own.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (FROZEN_MOBS.isEmpty()) {
				return;
			}
			long now = server.overworld().getGameTime();
			FROZEN_MOBS.entrySet().removeIf(entry -> {
				Mob mob = entry.getKey();
				if (!mob.isAlive()) {
					return true;
				}
				if (now >= entry.getValue()) {
					mob.setNoAi(false);
					return true;
				}
				mob.setDeltaMovement(Vec3.ZERO);
				return false;
			});
		});

		// Players have no AI to switch off, so freezing one means locking their position every
		// tick instead - this cancels movement input (walking, jumping, knockback, falling) by
		// snapping them straight back to where they were the instant Time Stop hit them. It can't
		// block attacking, using items, or breaking blocks in place - that would need intercepting
		// the network packets themselves, past what a plain item/event-based mod can reach into -
		// but it does stop a frozen player from going anywhere or being moved by anything else
		// until it expires.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (FROZEN_PLAYERS.isEmpty()) {
				return;
			}
			long now = server.overworld().getGameTime();
			FROZEN_PLAYERS.entrySet().removeIf(entry -> {
				ServerPlayer frozen = entry.getKey();
				FrozenPlayer state = entry.getValue();
				if (!frozen.isAlive() || frozen.hasDisconnected()) {
					return true;
				}
				if (now >= state.unfreezeAt) {
					return true;
				}
				frozen.teleportTo(state.lockedPosition.x, state.lockedPosition.y, state.lockedPosition.z);
				frozen.setDeltaMovement(Vec3.ZERO);
				frozen.fallDistance = 0.0D;
				return false;
			});
		});

	}

	// ---- Shared helper: keeps a relic's active/dormant texture in sync with its cooldown, and
	// spawns a light trail of golden particles around whoever's holding it while it's active -
	// this is the "glow item frame" look the community asked for, done server-side with particles
	// instead of a client light-override, since Golden Beam's particle trail already proves this
	// approach works reliably on this Minecraft version.
	// Called from each relic item's inventoryTick override.
	public static void tickActiveTexture(ItemStack stack, ServerLevel level, Entity holder, EquipmentSlot slot) {
		boolean ready = level.getGameTime() >= stack.getOrDefault(ABILITY_READY_AT, 0L);
		CustomModelData current = stack.get(DataComponents.CUSTOM_MODEL_DATA);
		boolean currentlyActive = current != null && !current.flags().isEmpty() && current.flags().get(0);
		if (ready != currentlyActive) {
			stack.set(DataComponents.CUSTOM_MODEL_DATA, ready ? ACTIVE_MODEL_DATA : DORMANT_MODEL_DATA);
		}
	}

	/**
	 * Permanently bakes Infinity onto a stack the first time it's seen, so Failnaught always
	 * fires without consuming arrows - "built in", not something that can be enchanted away via
	 * a grindstone re-roll landing on a stack that never had it to begin with.
	 */
	public static void ensureInfinity(ItemStack stack, ServerLevel level) {
		HolderGetter<Enchantment> enchantments = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		Holder<Enchantment> infinity = enchantments.getOrThrow(Enchantments.INFINITY);
		if (stack.getEnchantments().getLevel(infinity) <= 0) {
			stack.enchant(infinity, 1);
		}
	}

	private static boolean isReady(ItemStack stack, ServerLevel level) {
		return isReady(stack, level, ABILITY_READY_AT);
	}

	private static boolean isReady(ItemStack stack, ServerLevel level, DataComponentType<Long> component) {
		return level.getGameTime() >= stack.getOrDefault(component, 0L);
	}

	private static void setCooldown(ItemStack stack, ServerLevel level, int ticks) {
		setCooldown(stack, level, ticks, ABILITY_READY_AT);
	}

	private static void setCooldown(ItemStack stack, ServerLevel level, int ticks, DataComponentType<Long> component) {
		stack.set(component, level.getGameTime() + ticks);
	}

	private static void clearCooldown(ItemStack stack, ServerLevel level) {
		stack.set(ABILITY_READY_AT, level.getGameTime());
	}

	private static void dispatchMeleeAbility(ServerPlayer player) {
		ItemStack mainHand = player.getMainHandItem();
		if (mainHand.is(AYMR)) {
			handleBlinkStrike(player, mainHand);
		} else if (mainHand.is(SWORD_OF_THE_CREATOR)) {
			handleSublimeHeaven(player, mainHand);
		} else if (mainHand.is(AREADBHAR)) {
			handleCrestSurge(player, mainHand);
		}
	}

	/**
	 * Aymr - Blink Strike: teleports to the nearest other living entity within range and deals a
	 * large bonus blow, on top of the normal swing. Cooldown is skipped entirely on a one-shot
	 * kill, so you can chain through a pack as long as you keep one-shotting them.
	 */
	private static void handleBlinkStrike(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		LivingEntity target = findNearestOtherLivingEntity(player, level, BLINK_SEARCH_RADIUS);
		if (target == null) {
			return; // nothing to blink to - ability stays ready, no cooldown wasted
		}

		teleportNextTo(player, target);

		var damageSource = level.damageSources().playerAttack(player);
		target.hurtServer(level, damageSource, BLINK_BONUS_DAMAGE);
		AymrAxeItem.applyOnHitEffects(target, player);

		if (target.isDeadOrDying()) {
			clearCooldown(stack, level);
		} else {
			setCooldown(stack, level, BLINK_COOLDOWN_TICKS);
		}
	}

	/**
	 * Purely visual: a ring of fire particles traced out at exactly SUBLIME_HEAVEN_RADIUS around
	 * the player, so the AoE range is visible at a glance. Stacked at a few heights with a small
	 * clustered spread per point so it reads as a thick wall of flame rather than a thin line.
	 * Fires every time the ability actually triggers, even on a whiff (no cooldown burned either
	 * way when nothing's caught).
	 */
	private static void spawnSublimeHeavenRing(ServerLevel level, ServerPlayer player) {
		double baseY = player.getY();
		for (int i = 0; i < SUBLIME_HEAVEN_RING_POINTS; i++) {
			double angle = (2.0D * Math.PI * i) / SUBLIME_HEAVEN_RING_POINTS;
			double x = player.getX() + SUBLIME_HEAVEN_RADIUS * Math.cos(angle);
			double z = player.getZ() + SUBLIME_HEAVEN_RADIUS * Math.sin(angle);
			for (double heightOffset : SUBLIME_HEAVEN_RING_HEIGHTS) {
				level.sendParticles(
						ParticleTypes.FLAME,
						x, baseY + heightOffset, z,
						SUBLIME_HEAVEN_RING_PARTICLES_PER_POINT,
						0.15D, 0.15D, 0.15D,
						0.01D
				);
			}
		}
	}

	/**
	 * Sword of the Creator - Sublime Heaven: an extended sweeping-edge burst that damages every
	 * living entity in a radius around the player, not just whatever's directly in front. Same
	 * "no cooldown on a one-shot kill" chaining rule as Aymr, just a shorter base cooldown.
	 */
	private static void handleSublimeHeaven(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		spawnSublimeHeavenRing(level, player);

		AABB burstBox = player.getBoundingBox().inflate(SUBLIME_HEAVEN_RADIUS);
		List<LivingEntity> caught = level.getEntitiesOfClass(
				LivingEntity.class,
				burstBox,
				entity -> entity != player && entity.isAlive() && entity.distanceTo(player) <= SUBLIME_HEAVEN_RADIUS
		);

		if (caught.isEmpty()) {
			return; // nothing to hit - ability stays ready
		}

		var damageSource = level.damageSources().playerAttack(player);
		boolean scoredKill = false;
		for (LivingEntity entity : caught) {
			entity.hurtServer(level, damageSource, SUBLIME_HEAVEN_DAMAGE);
			double dx = entity.getX() - player.getX();
			double dz = entity.getZ() - player.getZ();
			Vec3 push = new Vec3(dx, 0.25D, dz);
			push = push.lengthSqr() > 1.0E-4D ? push.normalize() : new Vec3(0.0D, 1.0D, 0.0D);
			entity.setDeltaMovement(entity.getDeltaMovement().add(push.scale(1.4D)));
			if (entity.isDeadOrDying()) {
				scoredKill = true;
			}
		}

		if (scoredKill) {
			clearCooldown(stack, level);
		} else {
			setCooldown(stack, level, SUBLIME_HEAVEN_COOLDOWN_TICKS);
		}
	}

	/**
	 * Sword of the Creator - Time Stop: shift-right-click, entirely separate from Sublime Heaven's
	 * attack-key trigger and tracked on its own cooldown. A true "rewind" of mined blocks and
	 * killed entities isn't something that can be done reliably - there's no general, safe way to
	 * undo arbitrary world edits or bring back a specific dead entity in vanilla - so this is the
	 * freeze alternative: every non-player mob in range is genuinely frozen (AI fully off, not
	 * just slowed) for a full minute, on a much longer cooldown to match how strong that is.
	 */
	public static void handleTimeStop(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level, TIME_STOP_READY_AT)) {
			return;
		}

		AABB box = player.getBoundingBox().inflate(TIME_STOP_RADIUS);
		List<Mob> caughtMobs = level.getEntitiesOfClass(
				Mob.class,
				box,
				mob -> mob.isAlive() && mob.distanceTo(player) <= TIME_STOP_RADIUS
		);
		List<ServerPlayer> caughtPlayers = level.getEntitiesOfClass(
				ServerPlayer.class,
				box,
				other -> other != player && other.isAlive() && other.distanceTo(player) <= TIME_STOP_RADIUS
		);

		long unfreezeAt = level.getGameTime() + TIME_STOP_DURATION_TICKS;
		for (Mob mob : caughtMobs) {
			mob.setNoAi(true);
			mob.setDeltaMovement(Vec3.ZERO);
			FROZEN_MOBS.put(mob, unfreezeAt);
		}
		for (ServerPlayer other : caughtPlayers) {
			FROZEN_PLAYERS.put(other, new FrozenPlayer(other.position(), unfreezeAt));
			other.sendOverlayMessage(Component.literal("Time Stopped!"));
		}

		player.sendOverlayMessage(Component.literal("Time Stop"));
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.7F, 0.6F);
		level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0D, player.getZ(), 60, 2.0D, 1.5D, 2.0D, 0.02D);

		setCooldown(stack, level, TIME_STOP_COOLDOWN_TICKS, TIME_STOP_READY_AT);
	}

	/**
	 * Areadbhar - Crest Surge: grants a burst of Strength, and calls down a real lightning bolt
	 * on the nearest enemy within range (attributed to the player, same as a Channeling trident)
	 * - purely part of the active ability, not on normal hits.
	 */
	private static void handleCrestSurge(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, CREST_SURGE_DURATION_TICKS, CREST_SURGE_AMPLIFIER));

		LivingEntity target = findNearestOtherLivingEntity(player, level, CREST_SURGE_LIGHTNING_RADIUS);
		if (target != null) {
			LightningBolt bolt = new LightningBolt(EntityTypes.LIGHTNING_BOLT, level);
			bolt.setPos(target.getX(), target.getY(), target.getZ());
			bolt.setCause(player);
			level.addFreshEntity(bolt);
		}

		setCooldown(stack, level, CREST_SURGE_COOLDOWN_TICKS);
	}

	/**
	 * Failnaught - Fallen Star: grants Resistance plus a burst of extra power whenever an arrow
	 * is fired, on a flat cooldown. Triggered directly from {@code FailnaughtBowItem#releaseUsing}
	 * rather than through the network payload, since firing a bow is already a server-side hook.
	 */
	public static void handleFallenStar(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, FALLEN_STAR_DURATION_TICKS, FALLEN_STAR_RESISTANCE_AMPLIFIER));
		player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, FALLEN_STAR_DURATION_TICKS, FALLEN_STAR_STRENGTH_AMPLIFIER));
		setCooldown(stack, level, FALLEN_STAR_COOLDOWN_TICKS);
	}

	/**
	 * Failnaught - Golden Beam: fired instead of a normal arrow whenever the bow is held at full
	 * draw (see {@code FailnaughtBowItem#releaseUsing}). A straight, piercing line of damage out
	 * from the player's eyes with a short golden particle trail. Not gated by the ability
	 * cooldown itself - the draw time already rate-limits it - but still grants Fallen Star.
	 */
	public static void fireGoldenBeam(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();

		Vec3 start = player.getEyePosition();
		Vec3 end = start.add(player.getLookAngle().scale(BEAM_RANGE));

		AABB beamBounds = new AABB(start, end).inflate(1.0D);
		List<LivingEntity> caught = level.getEntitiesOfClass(
				LivingEntity.class,
				beamBounds,
				entity -> entity != player && entity.isAlive()
		);

		var damageSource = level.damageSources().playerAttack(player);
		for (LivingEntity entity : caught) {
			if (entity.getBoundingBox().inflate(0.3D).clip(start, end).isPresent()) {
				entity.hurtServer(level, damageSource, BEAM_DAMAGE);
				entity.setRemainingFireTicks(Math.max(entity.getRemainingFireTicks(), BEAM_FIRE_TICKS));
			}
		}

		spawnBeamParticles(level, start, end);
		ACTIVE_BEAMS.add(new BeamEffect(level, start, end, BEAM_LINGER_TICKS));
		fireBeamArrows(player, stack);

		handleFallenStar(player, stack);
	}

	/**
	 * Fires a small fan of real arrows (not just particles) alongside the Golden Beam, centered
	 * on the player's exact look direction. These are bonus arrows - not drawn from the player's
	 * inventory, same spirit as the beam itself replacing the normal shot on a full draw. Each
	 * arrow gets the bow's own actual enchantments (Power, Flame, Punch, etc.) applied through the
	 * same data-driven hook vanilla uses for a normal shot, so Failnaught's real enchantments -
	 * whatever they are - carry over automatically rather than being hardcoded here.
	 */
	private static void fireBeamArrows(ServerPlayer player, ItemStack bowStack) {
		ServerLevel level = (ServerLevel) player.level();
		Vec3 look = player.getLookAngle();

		// Center arrow plus one on either side, fanned out by BEAM_ARROW_SPREAD_DEGREES.
		int half = BEAM_ARROW_COUNT / 2;
		for (int i = 0; i < BEAM_ARROW_COUNT; i++) {
			float offsetSteps = i - half;
			Vec3 direction = offsetSteps == 0
					? look
					: look.yRot((float) Math.toRadians(offsetSteps * BEAM_ARROW_SPREAD_DEGREES));

			Arrow arrow = new Arrow(level, player, new ItemStack(Items.ARROW), bowStack);
			arrow.setPos(player.getEyePosition());
			arrow.shoot(direction.x, direction.y, direction.z, BEAM_ARROW_VELOCITY, BEAM_ARROW_INACCURACY);
			arrow.setBaseDamage(6.0D);
			arrow.setOwner(player);

			// Applies Power/Flame/Punch/etc from the bow's real enchantments onto this arrow -
			// the exact same hook BowItem itself uses internally for a normal shot.
			EnchantmentHelper.onProjectileSpawned(level, bowStack, arrow, item -> {});

			level.addFreshEntity(arrow);
		}
	}

	private static void spawnBeamParticles(ServerLevel level, Vec3 start, Vec3 end) {
		double length = start.distanceTo(end);
		int steps = Math.max(1, (int) (length / 0.5D));
		for (int i = 0; i <= steps; i++) {
			Vec3 point = start.lerp(end, (double) i / steps);
			level.sendParticles(GOLD_BEAM_DUST, point.x, point.y, point.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
		}
	}

	private static LivingEntity findNearestOtherLivingEntity(ServerPlayer player, ServerLevel level, double radius) {
		AABB searchBox = player.getBoundingBox().inflate(radius);
		List<LivingEntity> nearby = level.getEntitiesOfClass(
				LivingEntity.class,
				searchBox,
				entity -> entity != player && entity.isAlive() && entity.distanceTo(player) <= radius
		);
		return nearby.stream().min(Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
	}

	private static void teleportNextTo(ServerPlayer player, LivingEntity target) {
		Vec3 fromTargetToPlayer = player.position().subtract(target.position());
		double horizontalLength = Math.sqrt(fromTargetToPlayer.x * fromTargetToPlayer.x + fromTargetToPlayer.z * fromTargetToPlayer.z);

		double nx = 1.0D;
		double nz = 0.0D;
		if (horizontalLength > 0.001D) {
			nx = fromTargetToPlayer.x / horizontalLength;
			nz = fromTargetToPlayer.z / horizontalLength;
		}

		double destX = target.getX() + nx * 1.5D;
		double destY = target.getY();
		double destZ = target.getZ() + nz * 1.5D;

		player.teleportTo(destX, destY, destZ);
	}

	// ---- Monado ---------------------------------------------------------------

	public static String getMonadoMode(ItemStack stack) {
		CustomModelData data = stack.get(DataComponents.CUSTOM_MODEL_DATA);
		if (data == null || data.strings().isEmpty()) {
			return MONADO_MODE_OFF;
		}
		return data.strings().get(0);
	}

	private static void setMonadoMode(ItemStack stack, String mode) {
		stack.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(List.of(), List.of(), List.of(mode), List.of()));
	}

	private static String monadoModeDisplayName(String mode) {
		return mode.substring(0, 1).toUpperCase() + mode.substring(1);
	}

	/**
	 * Shift-right-click handler: advances to the next of the eight states (off, plus the seven
	 * Monado Arts) and shows an action-bar message naming it. The actual buffs are applied
	 * separately, every tick, by tickMonadoEffects - this just changes which state is selected.
	 */
	public static void cycleMonadoMode(ServerPlayer player, ItemStack stack, ServerLevel level) {
		String current = getMonadoMode(stack);
		int nextIndex = (MONADO_MODES.indexOf(current) + 1) % MONADO_MODES.size();
		String next = MONADO_MODES.get(nextIndex);
		setMonadoMode(stack, next);
		player.sendOverlayMessage(Component.literal("Monado Art: " + monadoModeDisplayName(next)));
		level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 0.6F, 1.6F);
	}

	/**
	 * Applies whichever passive buffs the currently-selected mode grants to whoever is holding
	 * Monado in either hand right now, and cleans up the two toggleable attribute bonuses
	 * (Buster's bonus damage, Smash's bonus knockback) the instant Monado is no longer held -
	 * driven top-down from current state each tick rather than needing an unequip hook.
	 */
	private static void tickMonadoEffects(ServerPlayer player) {
		ItemStack mainHand = player.getMainHandItem();
		ItemStack offHand = player.getOffhandItem();
		ItemStack monado = mainHand.is(MONADO) ? mainHand : (offHand.is(MONADO) ? offHand : ItemStack.EMPTY);

		if (monado.isEmpty()) {
			setAttributeBonus(player, Attributes.ATTACK_DAMAGE, MONADO_BUSTER_DAMAGE_ID, 0.0D);
			setAttributeBonus(player, Attributes.ATTACK_KNOCKBACK, MONADO_SMASH_KNOCKBACK_ID, 0.0D);
			return;
		}

		String mode = getMonadoMode(monado);
		boolean speed = mode.equals(MONADO_MODE_SPEED) || mode.equals(MONADO_MODE_GOD);
		boolean jump = mode.equals(MONADO_MODE_JUMP) || mode.equals(MONADO_MODE_GOD);
		boolean buster = mode.equals(MONADO_MODE_BUSTER) || mode.equals(MONADO_MODE_GOD);
		boolean shield = mode.equals(MONADO_MODE_SHIELD) || mode.equals(MONADO_MODE_GOD);
		boolean smash = mode.equals(MONADO_MODE_SMASH) || mode.equals(MONADO_MODE_GOD);

		if (speed) {
			player.addEffect(new MobEffectInstance(MobEffects.SPEED, MONADO_EFFECT_DURATION_TICKS, MONADO_SPEED_AMPLIFIER, true, false, true));
		}
		if (jump) {
			player.addEffect(new MobEffectInstance(MobEffects.JUMP_BOOST, MONADO_EFFECT_DURATION_TICKS, MONADO_JUMP_AMPLIFIER, true, false, true));
			// "slow falling or just negates fall damage" - Slow Falling inherently prevents fall
			// damage entirely while active, so one effect satisfies both phrasings at once.
			player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, MONADO_EFFECT_DURATION_TICKS, 0, true, false, true));
		}
		if (buster) {
			player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, MONADO_EFFECT_DURATION_TICKS, MONADO_BUSTER_STRENGTH_AMPLIFIER, true, false, true));
		}
		if (shield) {
			player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, MONADO_EFFECT_DURATION_TICKS, MONADO_SHIELD_RESISTANCE_AMPLIFIER, true, false, true));
			player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, MONADO_EFFECT_DURATION_TICKS, MONADO_SHIELD_ABSORPTION_AMPLIFIER, true, false, true));
		}
		if (smash) {
			player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, MONADO_EFFECT_DURATION_TICKS, MONADO_SMASH_STRENGTH_AMPLIFIER, true, false, true));
		}

		setAttributeBonus(player, Attributes.ATTACK_DAMAGE, MONADO_BUSTER_DAMAGE_ID, buster ? MONADO_BUSTER_DAMAGE_BONUS : 0.0D);
		setAttributeBonus(player, Attributes.ATTACK_KNOCKBACK, MONADO_SMASH_KNOCKBACK_ID, smash ? MONADO_SMASH_KNOCKBACK_BONUS : 0.0D);
	}

	private static void setAttributeBonus(ServerPlayer player, Holder<Attribute> attribute, Identifier modifierId, double amount) {
		AttributeInstance instance = player.getAttribute(attribute);
		if (instance == null) {
			return;
		}
		if (amount == 0.0D) {
			instance.removeModifier(modifierId);
		} else {
			instance.addOrUpdateTransientModifier(new AttributeModifier(modifierId, amount, AttributeModifier.Operation.ADD_VALUE));
		}
	}

	/**
	 * Purge (and God, which includes Purge's effect too) strip every positive/beneficial
	 * effect from whatever was just hit - the opposite of a splash effect, applied once per
	 * landed melee hit via MonadoItem#hurtEnemy.
	 */
	public static void stripPositiveEffects(LivingEntity target) {
		List<Holder<MobEffect>> toRemove = new ArrayList<>();
		for (MobEffectInstance instance : target.getActiveEffects()) {
			if (instance.getEffect().value().isBeneficial()) {
				toRemove.add(instance.getEffect());
			}
		}
		toRemove.forEach(target::removeEffect);
	}
}
