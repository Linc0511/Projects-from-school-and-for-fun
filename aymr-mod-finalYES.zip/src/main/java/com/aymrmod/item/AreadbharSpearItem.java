package com.aymrmod.item;

import com.aymrmod.AymrMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Areadbhar - relic spear. As of 26.2 there is no dedicated SpearItem class; the vanilla spear
 * weapons (wooden_spear .. netherite_spear) are all plain Item instances built with
 * Item.Properties#spear(ToolMaterial, ...9 floats), the same way sword uses .sword(...). See the
 * AREADBHAR registration in AymrMod.java for the actual property values, taken directly from
 * vanilla's own netherite_spear registration.
 */
public class AreadbharSpearItem extends Item {

	public AreadbharSpearItem(Properties properties) {
		super(properties);
	}

	@Override
	public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		AymrMod.tickActiveTexture(stack, level, entity, slot);
	}
}
