package com.aymrmod.item;

import com.aymrmod.AymrMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.phys.Vec3;

/**
 * Aymr - a relic axe forged from a Crest Stone.
 * <p>
 * Every hit sets the target on fire, inflicts Wither ("withering fire"), and applies heavy
 * bonus knockback. The teleport "blink strike" ability lives in {@code AymrMod}, since it is
 * triggered by the attack key itself (via a network payload) rather than only on a landed hit -
 * see {@code AymrModClient} for the trigger and {@code AymrMod.handleBlinkStrike} for the logic.
 * <p>
 * The item also swaps between a "dormant" (grey) and "active" (glowing) texture depending on
 * whether the blink strike is off cooldown - see the {@code minecraft:condition} client item at
 * {@code assets/aymr/items/aymr.json}, driven by the boolean flag written in
 * {@link #inventoryTick}.
 */
public class AymrAxeItem extends AxeItem {

	public AymrAxeItem(ToolMaterial material, float attackDamage, float attackSpeed, Properties properties) {
		super(material, attackDamage, attackSpeed, properties);
	}

	@Override
	public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		super.hurtEnemy(stack, target, attacker);

		if (!attacker.level().isClientSide()) {
			applyOnHitEffects(target, attacker);
		}
	}

	@Override
	public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		AymrMod.tickActiveTexture(stack, level, entity, slot);
	}

	/**
	 * Shared "on hit" flavor effects, used both by normal melee hits (hurtEnemy above) and by
	 * the teleport blink-strike bonus hit in {@code AymrMod.handleBlinkStrike}.
	 */
	public static void applyOnHitEffects(LivingEntity target, LivingEntity attacker) {
		target.setRemainingFireTicks(Math.max(target.getRemainingFireTicks(), AymrMod.ON_HIT_FIRE_TICKS));
		target.addEffect(new MobEffectInstance(MobEffects.WITHER, AymrMod.ON_HIT_WITHER_TICKS, AymrMod.ON_HIT_WITHER_AMPLIFIER));

		// Applied directly via velocity rather than the LivingEntity#knockback(...) convenience
		// method, whose exact overload has shifted across versions - getDeltaMovement/
		// setDeltaMovement are the low-level, version-stable primitives every knockback path
		// ultimately bottoms out in.
		double dx = target.getX() - attacker.getX();
		double dz = target.getZ() - attacker.getZ();
		Vec3 push = new Vec3(dx, 0.35D, dz);
		push = push.lengthSqr() > 1.0E-4D ? push.normalize() : new Vec3(0.0D, 1.0D, 0.0D);
		target.setDeltaMovement(target.getDeltaMovement().add(push.scale(AymrMod.ON_HIT_KNOCKBACK)));
	}
}
