package com.aymrmod.item;

import com.aymrmod.AymrMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Failnaught - a relic bow.
 * <p>
 * A normal (partial-draw) shot fires an ordinary arrow and grants Fallen Star, same as before.
 * Holding the draw to a full charge (~1s) instead fires the Golden Beam - a straight, piercing
 * line of gold-particle damage - in place of a physical arrow. See {@code AymrMod.fireGoldenBeam}.
 */
public class FailnaughtBowItem extends BowItem {

	public FailnaughtBowItem(Properties properties) {
		super(properties);
	}

	@Override
	public boolean releaseUsing(ItemStack stack, Level level, LivingEntity livingEntity, int timeLeft) {
		int chargeTicks = getUseDuration(stack, livingEntity) - timeLeft;

		// Full draw fires the Golden Beam instead of a normal arrow entirely - skips calling
		// super.releaseUsing() so it doesn't also consume/fire a physical arrow.
		if (!level.isClientSide() && livingEntity instanceof ServerPlayer player && chargeTicks >= AymrMod.BEAM_FULL_CHARGE_TICKS) {
			AymrMod.fireGoldenBeam(player, stack);
			return true;
		}

		// releaseUsing returns boolean as of 26.2 (previously void). We don't change vanilla
		// behavior at all - just relay whatever super returns - and hook our ability logic on
		// top as a side effect, same as before.
		boolean result = super.releaseUsing(stack, level, livingEntity, timeLeft);

		if (level.isClientSide() || !(livingEntity instanceof ServerPlayer player)) {
			return result;
		}

		if (chargeTicks < 5) {
			return result; // too brief a draw to count as an actual shot
		}

		AymrMod.handleFallenStar(player, stack);
		return result;
	}

	@Override
	public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		AymrMod.ensureInfinity(stack, level);
		AymrMod.tickActiveTexture(stack, level, entity, slot);
	}
}
