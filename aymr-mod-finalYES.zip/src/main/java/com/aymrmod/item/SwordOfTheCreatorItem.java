package com.aymrmod.item;

import com.aymrmod.AymrMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ToolMaterial;

/**
 * Sword of the Creator - a relic sword whose active ability, Sublime Heaven (see
 * {@code AymrMod.handleSublimeHeaven}), is an extended sweeping-edge burst that hits every living
 * entity in a radius around the player rather than just whatever's directly in front. Triggered
 * by the attack key via {@code ActivateRelicPayload}, same as Aymr's blink strike.
 * <p>
 * As of 26.2, {@code SwordItem} no longer exists - sword behavior lives in the vanilla
 * {@code minecraft:weapon} data component instead, attached via {@link Properties#sword}. This
 * now extends plain {@link Item}, same as any other tiered weapon.
 */
public class SwordOfTheCreatorItem extends Item {

	public SwordOfTheCreatorItem(ToolMaterial material, float attackDamage, float attackSpeed, Properties properties) {
		super(properties.sword(material, attackDamage, attackSpeed));
	}

	@Override
	public void inventoryTick(ItemStack stack, ServerLevel level, Entity entity, EquipmentSlot slot) {
		super.inventoryTick(stack, level, entity, slot);
		AymrMod.tickActiveTexture(stack, level, entity, slot);
	}
}
