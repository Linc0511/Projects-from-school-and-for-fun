package com.aymrmod.network;

import com.aymrmod.AymrMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Sent client -> server whenever the player presses attack while holding a melee/spear relic
 * (Aymr, Sword of the Creator, or Areadbhar). Carries no data - the server looks at whichever
 * item is actually in the player's main hand and dispatches to that weapon's ability.
 * <p>
 * Failnaught doesn't use this - its ability triggers off firing an arrow instead, which is
 * already a server-side hook ({@code FailnaughtBowItem#releaseUsing}), so it needs no payload.
 */
public record ActivateRelicPayload() implements CustomPacketPayload {

	public static final Identifier PAYLOAD_ID = AymrMod.id("activate_relic");

	public static final CustomPacketPayload.Type<ActivateRelicPayload> TYPE =
			new CustomPacketPayload.Type<>(PAYLOAD_ID);

	public static final StreamCodec<RegistryFriendlyByteBuf, ActivateRelicPayload> CODEC =
			StreamCodec.unit(new ActivateRelicPayload());

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
