package com.aymrmod;

import com.aymrmod.item.AreadbharSpearItem;
import com.aymrmod.item.AymrAxeItem;
import com.aymrmod.item.FailnaughtBowItem;
import com.aymrmod.item.SwordOfTheCreatorItem;
import com.aymrmod.network.ActivateRelicPayload;
import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

public class AymrMod implements ModInitializer {

	public static final String MOD_ID = "aymr";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	// ---- Tunables ---------------------------------------------------------

	// Aymr - Blink Strike
	public static final float BLINK_BONUS_DAMAGE = 100.0F;
	public static final double BLINK_SEARCH_RADIUS = 12.0D;
	public static final int BLINK_COOLDOWN_TICKS = 25; // 3s

	// Aymr - on-hit flavor (fire / withering fire / knockback)
	public static final float ON_HIT_KNOCKBACK = 2.2F;
	public static final int ON_HIT_FIRE_TICKS = 250;
	public static final int ON_HIT_WITHER_TICKS = 250;
	public static final int ON_HIT_WITHER_AMPLIFIER = 10;

	// Sword of the Creator - Sublime Heaven (AoE sweep)
	public static final float SUBLIME_HEAVEN_DAMAGE = 25.0F;
	public static final double SUBLIME_HEAVEN_RADIUS = 9.0D;
	public static final int SUBLIME_HEAVEN_COOLDOWN_TICKS = 20; // 3s

	// Areadbhar - Crest Surge (self buff)
	public static final int CREST_SURGE_DURATION_TICKS = 600; // 10s
	public static final int CREST_SURGE_AMPLIFIER = 5; // Strength III
	public static final int CREST_SURGE_COOLDOWN_TICKS = 20; // 15s
	public static final double CREST_SURGE_LIGHTNING_RADIUS = 12.0D;

	// Failnaught - Fallen Star (self buff on firing an arrow)
	public static final int FALLEN_STAR_DURATION_TICKS = 200; // 10s
	public static final int FALLEN_STAR_RESISTANCE_AMPLIFIER = 10; // Resistance II
	public static final int FALLEN_STAR_STRENGTH_AMPLIFIER = 6; // Strength II
	public static final int FALLEN_STAR_COOLDOWN_TICKS = 20; // 15s

	// Failnaught - Golden Beam (fully-charged shot instead of a normal arrow)
	public static final double BEAM_RANGE = 40.0D;
	public static final float BEAM_DAMAGE = 45.0F;
	public static final int BEAM_FULL_CHARGE_TICKS = 20; // ~1s hold - matches vanilla's own "fully drawn" threshold
	public static final int BEAM_LINGER_TICKS = 12; // ~0.6s of trailing particles after the hit
	public static final int BEAM_FIRE_TICKS = 60;
	public static final int BEAM_ARROW_COUNT = 3;
	public static final float BEAM_ARROW_SPREAD_DEGREES = 8.0F; // fan angle between each bonus arrow
	public static final float BEAM_ARROW_VELOCITY = 3.0F;
	public static final float BEAM_ARROW_INACCURACY = 0.0F; // dead straight, matches the beam

	// Sword of the Creator - Sublime Heaven range ring (visual only, shows the AoE radius)
	public static final int SUBLIME_HEAVEN_RING_POINTS = 72;
	public static final double[] SUBLIME_HEAVEN_RING_HEIGHTS = {0.1D, 0.5D, 0.9D};
	public static final int SUBLIME_HEAVEN_RING_PARTICLES_PER_POINT = 3;

	// Held-relic glow: keeps a relic's active/dormant texture in sync with its cooldown (see
	// tickActiveTexture)

	// ---- Identifiers --------------------------------------------------------
	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	// ---- Item resource keys --------------------------------------------------
	public static final ResourceKey<Item> CREST_STONE_KEY = ResourceKey.create(Registries.ITEM, id("crest_stone"));
	public static final ResourceKey<Item> AYMR_KEY = ResourceKey.create(Registries.ITEM, id("aymr"));
	public static final ResourceKey<Item> SWORD_OF_THE_CREATOR_KEY = ResourceKey.create(Registries.ITEM, id("sword_of_the_creator"));
	public static final ResourceKey<Item> AREADBHAR_KEY = ResourceKey.create(Registries.ITEM, id("areadbhar"));
	public static final ResourceKey<Item> FAILNAUGHT_KEY = ResourceKey.create(Registries.ITEM, id("failnaught"));

	// ---- Tags used by the custom tool material -------------------------------
	public static final TagKey<Block> INCORRECT_FOR_RELIC_TOOL =
			TagKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath("minecraft", "incorrect_for_netherite_tool"));
	public static final TagKey<Item> REPAIRS_RELICS = TagKey.create(Registries.ITEM, id("repairs_relics"));

	// Shared material for the edged relics (Aymr, Sword of the Creator).
	public static final ToolMaterial RELIC_MATERIAL = new ToolMaterial(
			INCORRECT_FOR_RELIC_TOOL,
			30000,   // durability (netherite is 2031)
			11.0F,  // mining speed
			15.0F,   // attack damage bonus
			28,     // enchantment value
			REPAIRS_RELICS
	);

	// ---- Custom data component: server game-time an ability is next usable ----
	// Shared by every relic weapon's active ability.
	public static final DataComponentType<Long> ABILITY_READY_AT = Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			id("ability_ready_at"),
			DataComponentType.<Long>builder().persistent(Codec.LONG).build()
	);

	private static final CustomModelData ACTIVE_MODEL_DATA = new CustomModelData(List.of(), List.of(true), List.of(), List.of());
	private static final CustomModelData DORMANT_MODEL_DATA = new CustomModelData(List.of(), List.of(false), List.of(), List.of());

	// ---- Golden Beam: short-lived trailing particle effect, ticked server-side ----
	private static final DustParticleOptions GOLD_BEAM_DUST = new DustParticleOptions(0xFFD126, 1.6F);
	private static final List<BeamEffect> ACTIVE_BEAMS = new ArrayList<>();

	private static final class BeamEffect {
		final ServerLevel level;
		final Vec3 start;
		final Vec3 end;
		int ticksRemaining;

		BeamEffect(ServerLevel level, Vec3 start, Vec3 end, int ticksRemaining) {
			this.level = level;
			this.start = start;
			this.end = end;
			this.ticksRemaining = ticksRemaining;
		}
	}

	// ---- Item registration helper (mirrors Mojang's own Items class pattern) ----
	public static Item register(ResourceKey<Item> itemKey, Function<Item.Properties, Item> itemFactory, Item.Properties settings) {
		Item item = itemFactory.apply(settings.setId(itemKey));
		Registry.register(BuiltInRegistries.ITEM, itemKey, item);
		return item;
	}

	private static Item.Properties relicProperties() {
		return new Item.Properties()
				.fireResistant()
				.component(ABILITY_READY_AT, 0L)
				.component(DataComponents.CUSTOM_MODEL_DATA, ACTIVE_MODEL_DATA);
	}

	public static final Item CREST_STONE = register(CREST_STONE_KEY, Item::new, new Item.Properties());

	public static final Item AYMR = register(
			AYMR_KEY,
			settings -> new AymrAxeItem(RELIC_MATERIAL, 16.0F, -3.0F, settings),
			relicProperties()
				.enchantable(25)
	);

	public static final Item SWORD_OF_THE_CREATOR = register(
			SWORD_OF_THE_CREATOR_KEY,
			settings -> new SwordOfTheCreatorItem(RELIC_MATERIAL, 12.0F, -2.4F, settings),
			relicProperties()
				.enchantable(25)
	);

	public static final Item AREADBHAR = register(
		AREADBHAR_KEY,
		settings -> new AreadbharSpearItem(
				settings.spear(RELIC_MATERIAL, 1.15F, 1.2F, 0.4F, 2.5F, 12.0F, 5.5F, 5.1F, 8.75F, 4.6F)
		),
		relicProperties().enchantable(25)
	);

	public static final Item FAILNAUGHT = register(
			FAILNAUGHT_KEY,
			FailnaughtBowItem::new,
			relicProperties().enchantable(25)
	);

	@Override
	public void onInitialize() {
		LOGGER.info("Forging the Hero's Relics...");

		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT)
				.register(creativeTab -> {
					creativeTab.accept(CREST_STONE);
					creativeTab.accept(AYMR);
					creativeTab.accept(SWORD_OF_THE_CREATOR);
					creativeTab.accept(AREADBHAR);
					creativeTab.accept(FAILNAUGHT);
				});

		PayloadTypeRegistry.serverboundPlay().register(ActivateRelicPayload.TYPE, ActivateRelicPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ActivateRelicPayload.TYPE, (payload, context) ->
				context.server().execute(() -> dispatchMeleeAbility(context.player())));

		// Ticks the Golden Beam's short trailing particle effect - see fireGoldenBeam below.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (ACTIVE_BEAMS.isEmpty()) {
				return;
			}
			ACTIVE_BEAMS.removeIf(beam -> {
				spawnBeamParticles(beam.level, beam.start, beam.end);
				beam.ticksRemaining--;
				return beam.ticksRemaining <= 0;
			});
		});

	}

	// ---- Shared helper: keeps a relic's active/dormant texture in sync with its cooldown, and
	// spawns a light trail of golden particles around whoever's holding it while it's active -
	// this is the "glow item frame" look the community asked for, done server-side with particles
	// instead of a client light-override, since Golden Beam's particle trail already proves this
	// approach works reliably on this Minecraft version.
	// Called from each relic item's inventoryTick override.
	public static void tickActiveTexture(ItemStack stack, ServerLevel level, Entity holder, EquipmentSlot slot) {
		boolean ready = level.getGameTime() >= stack.getOrDefault(ABILITY_READY_AT, 0L);
		CustomModelData current = stack.get(DataComponents.CUSTOM_MODEL_DATA);
		boolean currentlyActive = current != null && !current.flags().isEmpty() && current.flags().get(0);
		if (ready != currentlyActive) {
			stack.set(DataComponents.CUSTOM_MODEL_DATA, ready ? ACTIVE_MODEL_DATA : DORMANT_MODEL_DATA);
		}
	}

	/**
	 * Permanently bakes Infinity onto a stack the first time it's seen, so Failnaught always
	 * fires without consuming arrows - "built in", not something that can be enchanted away via
	 * a grindstone re-roll landing on a stack that never had it to begin with.
	 */
	public static void ensureInfinity(ItemStack stack, ServerLevel level) {
		HolderGetter<Enchantment> enchantments = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		Holder<Enchantment> infinity = enchantments.getOrThrow(Enchantments.INFINITY);
		if (stack.getEnchantments().getLevel(infinity) <= 0) {
			stack.enchant(infinity, 1);
		}
	}

	private static boolean isReady(ItemStack stack, ServerLevel level) {
		return level.getGameTime() >= stack.getOrDefault(ABILITY_READY_AT, 0L);
	}

	private static void setCooldown(ItemStack stack, ServerLevel level, int ticks) {
		stack.set(ABILITY_READY_AT, level.getGameTime() + ticks);
	}

	private static void clearCooldown(ItemStack stack, ServerLevel level) {
		stack.set(ABILITY_READY_AT, level.getGameTime());
	}

	private static void dispatchMeleeAbility(ServerPlayer player) {
		ItemStack mainHand = player.getMainHandItem();
		if (mainHand.is(AYMR)) {
			handleBlinkStrike(player, mainHand);
		} else if (mainHand.is(SWORD_OF_THE_CREATOR)) {
			handleSublimeHeaven(player, mainHand);
		} else if (mainHand.is(AREADBHAR)) {
			handleCrestSurge(player, mainHand);
		}
	}

	/**
	 * Aymr - Blink Strike: teleports to the nearest other living entity within range and deals a
	 * large bonus blow, on top of the normal swing. Cooldown is skipped entirely on a one-shot
	 * kill, so you can chain through a pack as long as you keep one-shotting them.
	 */
	private static void handleBlinkStrike(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		LivingEntity target = findNearestOtherLivingEntity(player, level, BLINK_SEARCH_RADIUS);
		if (target == null) {
			return; // nothing to blink to - ability stays ready, no cooldown wasted
		}

		teleportNextTo(player, target);

		var damageSource = level.damageSources().playerAttack(player);
		target.hurtServer(level, damageSource, BLINK_BONUS_DAMAGE);
		AymrAxeItem.applyOnHitEffects(target, player);

		if (target.isDeadOrDying()) {
			clearCooldown(stack, level);
		} else {
			setCooldown(stack, level, BLINK_COOLDOWN_TICKS);
		}
	}

	/**
	 * Purely visual: a ring of fire particles traced out at exactly SUBLIME_HEAVEN_RADIUS around
	 * the player, so the AoE range is visible at a glance. Stacked at a few heights with a small
	 * clustered spread per point so it reads as a thick wall of flame rather than a thin line.
	 * Fires every time the ability actually triggers, even on a whiff (no cooldown burned either
	 * way when nothing's caught).
	 */
	private static void spawnSublimeHeavenRing(ServerLevel level, ServerPlayer player) {
		double baseY = player.getY();
		for (int i = 0; i < SUBLIME_HEAVEN_RING_POINTS; i++) {
			double angle = (2.0D * Math.PI * i) / SUBLIME_HEAVEN_RING_POINTS;
			double x = player.getX() + SUBLIME_HEAVEN_RADIUS * Math.cos(angle);
			double z = player.getZ() + SUBLIME_HEAVEN_RADIUS * Math.sin(angle);
			for (double heightOffset : SUBLIME_HEAVEN_RING_HEIGHTS) {
				level.sendParticles(
						ParticleTypes.FLAME,
						x, baseY + heightOffset, z,
						SUBLIME_HEAVEN_RING_PARTICLES_PER_POINT,
						0.15D, 0.15D, 0.15D,
						0.01D
				);
			}
		}
	}

	/**
	 * Sword of the Creator - Sublime Heaven: an extended sweeping-edge burst that damages every
	 * living entity in a radius around the player, not just whatever's directly in front. Same
	 * "no cooldown on a one-shot kill" chaining rule as Aymr, just a shorter base cooldown.
	 */
	private static void handleSublimeHeaven(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		spawnSublimeHeavenRing(level, player);

		AABB burstBox = player.getBoundingBox().inflate(SUBLIME_HEAVEN_RADIUS);
		List<LivingEntity> caught = level.getEntitiesOfClass(
				LivingEntity.class,
				burstBox,
				entity -> entity != player && entity.isAlive() && entity.distanceTo(player) <= SUBLIME_HEAVEN_RADIUS
		);

		if (caught.isEmpty()) {
			return; // nothing to hit - ability stays ready
		}

		var damageSource = level.damageSources().playerAttack(player);
		boolean scoredKill = false;
		for (LivingEntity entity : caught) {
			entity.hurtServer(level, damageSource, SUBLIME_HEAVEN_DAMAGE);
			double dx = entity.getX() - player.getX();
			double dz = entity.getZ() - player.getZ();
			Vec3 push = new Vec3(dx, 0.25D, dz);
			push = push.lengthSqr() > 1.0E-4D ? push.normalize() : new Vec3(0.0D, 1.0D, 0.0D);
			entity.setDeltaMovement(entity.getDeltaMovement().add(push.scale(1.4D)));
			if (entity.isDeadOrDying()) {
				scoredKill = true;
			}
		}

		if (scoredKill) {
			clearCooldown(stack, level);
		} else {
			setCooldown(stack, level, SUBLIME_HEAVEN_COOLDOWN_TICKS);
		}
	}

	/**
	 * Areadbhar - Crest Surge: grants a burst of Strength, and calls down a real lightning bolt
	 * on the nearest enemy within range (attributed to the player, same as a Channeling trident)
	 * - purely part of the active ability, not on normal hits.
	 */
	private static void handleCrestSurge(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, CREST_SURGE_DURATION_TICKS, CREST_SURGE_AMPLIFIER));

		LivingEntity target = findNearestOtherLivingEntity(player, level, CREST_SURGE_LIGHTNING_RADIUS);
		if (target != null) {
			LightningBolt bolt = new LightningBolt(EntityTypes.LIGHTNING_BOLT, level);
			bolt.setPos(target.getX(), target.getY(), target.getZ());
			bolt.setCause(player);
			level.addFreshEntity(bolt);
		}

		setCooldown(stack, level, CREST_SURGE_COOLDOWN_TICKS);
	}

	/**
	 * Failnaught - Fallen Star: grants Resistance plus a burst of extra power whenever an arrow
	 * is fired, on a flat cooldown. Triggered directly from {@code FailnaughtBowItem#releaseUsing}
	 * rather than through the network payload, since firing a bow is already a server-side hook.
	 */
	public static void handleFallenStar(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();
		if (!isReady(stack, level)) {
			return;
		}

		player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, FALLEN_STAR_DURATION_TICKS, FALLEN_STAR_RESISTANCE_AMPLIFIER));
		player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, FALLEN_STAR_DURATION_TICKS, FALLEN_STAR_STRENGTH_AMPLIFIER));
		setCooldown(stack, level, FALLEN_STAR_COOLDOWN_TICKS);
	}

	/**
	 * Failnaught - Golden Beam: fired instead of a normal arrow whenever the bow is held at full
	 * draw (see {@code FailnaughtBowItem#releaseUsing}). A straight, piercing line of damage out
	 * from the player's eyes with a short golden particle trail. Not gated by the ability
	 * cooldown itself - the draw time already rate-limits it - but still grants Fallen Star.
	 */
	public static void fireGoldenBeam(ServerPlayer player, ItemStack stack) {
		ServerLevel level = (ServerLevel) player.level();

		Vec3 start = player.getEyePosition();
		Vec3 end = start.add(player.getLookAngle().scale(BEAM_RANGE));

		AABB beamBounds = new AABB(start, end).inflate(1.0D);
		List<LivingEntity> caught = level.getEntitiesOfClass(
				LivingEntity.class,
				beamBounds,
				entity -> entity != player && entity.isAlive()
		);

		var damageSource = level.damageSources().playerAttack(player);
		for (LivingEntity entity : caught) {
			if (entity.getBoundingBox().inflate(0.3D).clip(start, end).isPresent()) {
				entity.hurtServer(level, damageSource, BEAM_DAMAGE);
				entity.setRemainingFireTicks(Math.max(entity.getRemainingFireTicks(), BEAM_FIRE_TICKS));
			}
		}

		spawnBeamParticles(level, start, end);
		ACTIVE_BEAMS.add(new BeamEffect(level, start, end, BEAM_LINGER_TICKS));
		fireBeamArrows(player, stack);

		handleFallenStar(player, stack);
	}

	/**
	 * Fires a small fan of real arrows (not just particles) alongside the Golden Beam, centered
	 * on the player's exact look direction. These are bonus arrows - not drawn from the player's
	 * inventory, same spirit as the beam itself replacing the normal shot on a full draw. Each
	 * arrow gets the bow's own actual enchantments (Power, Flame, Punch, etc.) applied through the
	 * same data-driven hook vanilla uses for a normal shot, so Failnaught's real enchantments -
	 * whatever they are - carry over automatically rather than being hardcoded here.
	 */
	private static void fireBeamArrows(ServerPlayer player, ItemStack bowStack) {
		ServerLevel level = (ServerLevel) player.level();
		Vec3 look = player.getLookAngle();

		// Center arrow plus one on either side, fanned out by BEAM_ARROW_SPREAD_DEGREES.
		int half = BEAM_ARROW_COUNT / 2;
		for (int i = 0; i < BEAM_ARROW_COUNT; i++) {
			float offsetSteps = i - half;
			Vec3 direction = offsetSteps == 0
					? look
					: look.yRot((float) Math.toRadians(offsetSteps * BEAM_ARROW_SPREAD_DEGREES));

			Arrow arrow = new Arrow(level, player, new ItemStack(Items.ARROW), bowStack);
			arrow.setPos(player.getEyePosition());
			arrow.shoot(direction.x, direction.y, direction.z, BEAM_ARROW_VELOCITY, BEAM_ARROW_INACCURACY);
			arrow.setBaseDamage(6.0D);
			arrow.setOwner(player);

			// Applies Power/Flame/Punch/etc from the bow's real enchantments onto this arrow -
			// the exact same hook BowItem itself uses internally for a normal shot.
			EnchantmentHelper.onProjectileSpawned(level, bowStack, arrow, item -> {});

			level.addFreshEntity(arrow);
		}
	}

	private static void spawnBeamParticles(ServerLevel level, Vec3 start, Vec3 end) {
		double length = start.distanceTo(end);
		int steps = Math.max(1, (int) (length / 0.5D));
		for (int i = 0; i <= steps; i++) {
			Vec3 point = start.lerp(end, (double) i / steps);
			level.sendParticles(GOLD_BEAM_DUST, point.x, point.y, point.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
		}
	}

	private static LivingEntity findNearestOtherLivingEntity(ServerPlayer player, ServerLevel level, double radius) {
		AABB searchBox = player.getBoundingBox().inflate(radius);
		List<LivingEntity> nearby = level.getEntitiesOfClass(
				LivingEntity.class,
				searchBox,
				entity -> entity != player && entity.isAlive() && entity.distanceTo(player) <= radius
		);
		return nearby.stream().min(Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
	}

	private static void teleportNextTo(ServerPlayer player, LivingEntity target) {
		Vec3 fromTargetToPlayer = player.position().subtract(target.position());
		double horizontalLength = Math.sqrt(fromTargetToPlayer.x * fromTargetToPlayer.x + fromTargetToPlayer.z * fromTargetToPlayer.z);

		double nx = 1.0D;
		double nz = 0.0D;
		if (horizontalLength > 0.001D) {
			nx = fromTargetToPlayer.x / horizontalLength;
			nz = fromTargetToPlayer.z / horizontalLength;
		}

		double destX = target.getX() + nx * 1.5D;
		double destY = target.getY();
		double destZ = target.getZ() + nz * 1.5D;

		player.teleportTo(destX, destY, destZ);
	}
}
