package com.aymrmod.client;

import com.aymrmod.AymrMod;
import com.aymrmod.network.ActivateRelicPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.minecraft.world.item.Item;

public class AymrModClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		// Fires every time the attack key (left click) is pressed while holding a melee/spear
		// relic. Returning false leaves the normal vanilla attack intact, so each relic's active
		// ability is an *extra* effect layered on top of the regular swing. Failnaught isn't
		// included here - its ability triggers server-side off firing an arrow instead.
		ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> {
			if (clickCount != 0 && isMeleeRelic(player.getMainHandItem().getItem())) {
				ClientPlayNetworking.send(new ActivateRelicPayload());
			}
			return false;
		});
	}

	private static boolean isMeleeRelic(Item item) {
		return item == AymrMod.AYMR || item == AymrMod.SWORD_OF_THE_CREATOR || item == AymrMod.AREADBHAR;
	}
}
