# Hero's Relics

A Fabric mod for Minecraft **26.2 "Chaos Cubed"**, adding four Fire Emblem: Three Houses relics,
each forged from a Crest Stone. (Internal mod id is still `aymr` - renaming that fully would touch
every file's namespace for no functional benefit now that everything's compiling and working, so
only the display name/branding changed.)

## The relics

All four share the same "active/dormant" glowing-texture system, so you can tell an ability's
cooldown state from the weapon's appearance alone.

### Crest Stone
Crafted from a Nether Star (center), 4 Netherite Ingots (corners), and 4 Blocks of Iron (cardinal
directions). The shared ingredient for every relic below.

### Aymr (axe)
- Netherite-axe-based, hits far harder (custom `ToolMaterial`: more durability, mining speed,
  attack damage, enchantability).
- Every hit: fire, Wither ("withering fire"), and heavy bonus knockback.
- **Blink Strike** (left click): teleports to the nearest other living entity within 12 blocks and
  deals a large bonus blow. 3s cooldown, skipped entirely on a one-shot kill.
- Crafted from a Netherite Axe + Crest Stone + 2 Bone Blocks.

### Sword of the Creator (sword)
- Netherite-sword-based, shares Aymr's tool material.
- **Sublime Heaven** (left click): an extended sweeping-edge burst that damages *every* living
  entity within 5 blocks, not just whatever's directly in front. Same 3s cooldown /
  cooldown-skipped-on-a-kill rule as Aymr.
- Crafted from a Netherite Sword + Crest Stone + 2 Bone Blocks.

### Areadbhar (spear)
- A genuine vanilla Spear (Minecraft added a native tiered Spear weapon type), built via
  `Item.Properties#spear(...)` with heavier stats than the stock Netherite Spear.
- **Crest Surge** (left click): grants Strength III for 10s and calls down a real lightning bolt
  on the nearest enemy within 12 blocks (attributed to you, like a Channeling trident). 15s flat
  cooldown - no kill-skip, since it's a self-buff rather than a strike.
- Crafted from a Netherite Spear + Crest Stone + 2 Netherite Ingots.

### Failnaught (bow)
- Custom `BowItem`.
- **Fallen Star**: any shot grants Resistance II + Strength II for 10s, 15s cooldown. Triggers
  automatically off actually loosing an arrow (not a left-click payload), since firing a bow is
  already a server-side hook.
- **Golden Beam**: hold the draw to a full charge (~1 second) and release to fire a straight,
  piercing line of golden light instead of a normal arrow - hits everything along the line for
  heavy damage and sets it alight, with a short trailing golden particle effect. Not on the
  ability cooldown itself (the full draw time already rate-limits it), but still grants Fallen
  Star on top.
- Crafted from a Bow + Crest Stone + 2 Netherite Ingots.

## Enchanting

Each relic is added to the vanilla `minecraft:enchantable/*` tags matching its type (`axe`,
`sword`, `sharp_weapon`, `weapon`, `fire_aspect`, `trident`, `bow`, `durability`,
`vanishing_curse`, plus `mining`/`mining_loot` for Aymr) so ordinary enchanting-table enchantments
recognize them. If a specific vanilla enchantment still doesn't offer on one of them, it's most
likely missing one more tag category - let me know which enchantment/item and I'll add it.

## Recipe fix (crafting silently doing nothing)

If you crafted with an earlier build of this mod and nothing happened, that was a real bug: the
recipe JSON ingredients used the old `{"item": "minecraft:x"}` object-wrapped format. Minecraft
26.2 expects plain strings instead (`"minecraft:x"`, or `"#namespace:tag"` for a tag) - the old
object form gets silently rejected at datapack load, so the recipes never actually registered.
All five recipes now use the correct plain-string format.

## Recipe book

Each recipe now ships with a companion advancement (`data/aymr/advancement/recipes/*.json`) that
unlocks it in the recipe book once you've picked up the relevant ingredient (a Nether Star for the
Crest Stone; a Crest Stone for every weapon). This is what was missing before - Minecraft doesn't
auto-unlock custom datapack recipes without one of these.

## Why this looks different from a "normal" Fabric mod

Minecraft 26.1/26.2 dropped Yarn mappings entirely - mods now compile directly against Mojang's
official (deobfuscated) names, and Fabric Loom no longer remaps anything. If you see other AI-
generated code online for this mod (or for similar Fire Emblem crossover mods) using names like
`StatusEffects`, `PlayerEntity`, `postHit`, `ToolMaterials`, `ModelPredicateProviderRegistry`, or
`CustomPayload`, that's the *old* pre-26.1 API - none of it compiles here. This project uses the
current names throughout (`MobEffects`, `Player`/`ServerPlayer`, `hurtEnemy`, custom `ToolMaterial`,
the `minecraft:condition` item-model system, `CustomPacketPayload`, etc).

## Known lower-confidence spots

26.2 is only a couple of months old as of this writing, so a handful of very specific API calls
were written from the most stable long-standing Mojang naming conventions rather than a directly
confirmed 26.2 source snippet. If Gradle reports an unresolved-symbol error on one of these, it's
almost certainly just a rename:
- `Entity#teleportTo`, `Entity#setRemainingFireTicks`
- `Item.Properties#spear(...)` parameter order in `AymrMod` (Areadbhar's registration) - the 9
  floats are real (verified against a real doc source), but exact tuning may not match intent
- `BowItem#releaseUsing` / `Item#getUseDuration` in `FailnaughtBowItem`
- `AABB#clip(Vec3, Vec3)`, `ServerLevel#sendParticles`, `DustParticleOptions` in the Golden Beam
  code (`AymrMod.fireGoldenBeam`)
- `LightningBolt` construction / `bolt.setCause(player)` in Areadbhar's Crest Surge
- `ServerPlayNetworking.Context#server()`

If you hit one, paste me the exact compiler error the same way you have been - it's usually a
one-line fix.

## Building

1. Install JDK 25 (or let Gradle auto-download it - `settings.gradle` includes the
   `foojay-resolver-convention` plugin for this).
2. Open the project folder in IntelliJ IDEA, or run:
   ```
   ./gradlew build
   ```
3. The built mod jar will be in `build/libs/aymr-1.0.0.jar`.
4. Drop it into a Fabric 26.2 instance's `mods` folder, alongside Fabric API 0.156.0+26.2 or newer.

## Customizing

- All numeric tuning (damage, knockback, radii, buff durations/amplifiers, cooldowns) lives at the
  top of `AymrMod.java`.
- Recipes are plain JSON in `src/main/resources/data/aymr/recipe/` - edit freely.
- Textures are in `src/main/resources/assets/aymr/textures/item/` - `_active`/`_dormant` pairs for
  each weapon, `crest_stone.png` for the crafting material.

## Shader glow (Iris/OptiFine, e.g. Solas Shader)

Each `_active` weapon texture, plus `crest_stone.png`, now ships with a companion `_s.png`
specular/PBR map (e.g. `aymr_active_s.png`) using the LabPBR standard. Its alpha channel marks
the warm/bright (orange-gold-red) pixels as emissive, so under a PBR-aware shaderpack those areas
actually glow and bloom instead of just looking bright. This is pure resource-pack data - no Java
code involved, and it degrades gracefully to normal (non-glowing) rendering with no shaders or a
non-PBR shaderpack.

If you retexture a weapon (including swapping in a Blockbench-exported model texture) and want
the glow to keep matching, just ask - the specular maps are auto-generated from whichever pixels
in the current texture are warm-colored and bright, not hand-painted, so they can be regenerated
from any new art in seconds.
